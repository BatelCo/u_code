

# res = ""
# for char in "text":
#   number = get_number(char)
#   number += 1
#   next_char = parse_to_char(number)
#   res += next_char


#   res = "".join([parse_to_char(get_number(c)+1) for c in "text"])

ord('C')  # 67
